/**
 * Rilevamento intent speciali nella query PRIMA del search engine.
 *
 * Se rileva un intent speciale, restituisce il risultato direttamente.
 * Se nessun intent rilevato, restituisce null → procedi con BM25.
 *
 * Attualmente supportato:
 * - Verifica IBAN: rileva codici IBAN (IT + 25 caratteri alfanumerici)
 */

const https = require("https");
const http = require("http");

// Pattern IBAN: 2 lettere codice paese + 2 cifre di controllo + fino a 30 alfanumerici
// Italiano: IT + 2 cifre + 1 lettera + 22 alfanumerici = 27 caratteri totali
const IBAN_PATTERN = /\b([A-Z]{2}\d{2}[A-Z0-9]{10,30})\b/i;

const IBAN_CHECKER_URL = "https://svvdkj0vl3.execute-api.eu-west-1.amazonaws.com//default/IbanCheckerV2";

/**
 * Controlla se la query contiene un intent speciale.
 * @param {string} query - Query dell'utente
 * @returns {{ intent: string, result: Object } | null}
 */
function detectIntent(query) {
  const iban = extractIban(query);
  if (iban) {
    // Nota: la verifica IBAN è asincrona nell'originale Python.
    // Qui restituiamo un messaggio di cortesia. Per la versione completa,
    // serve una chiamata HTTP asincrona al webhook.
    return {
      intent: "iban_verification",
      result: {
        iban,
        formatted: `**Verifica IBAN**\n\n- **IBAN:** \`${iban}\`\n- Per la verifica completa, utilizzare il servizio dedicato.`,
      },
    };
  }

  return null;
}

/**
 * Estrae un codice IBAN dal testo della query.
 * Gestisce sia IBAN compatti che con spazi.
 *
 * @param {string} query - Testo della query
 * @returns {string|null} Codice IBAN o null
 */
function extractIban(query) {
  const upper = query.toUpperCase();

  // Primo tentativo: pattern IBAN diretto
  let match = upper.match(IBAN_PATTERN);
  if (match) {
    const iban = match[1];
    if (iban.startsWith("IT") && iban.length === 27) return iban;
    if (iban.length >= 15) return iban;
  }

  // Secondo tentativo: rimuovi spazi e riprova (utenti incollano con spazi)
  const noSpaces = upper.replace(/\s+/g, "");
  match = noSpaces.match(IBAN_PATTERN);
  if (match) {
    const iban = match[1];
    if (iban.startsWith("IT") && iban.length === 27) return iban;
    if (iban.length >= 15) return iban;
  }

  return null;
}

/**
 * Chiama il webhook di verifica IBAN (versione asincrona).
 * Usare se si vuole integrare la verifica completa.
 *
 * @param {string} iban - Codice IBAN da verificare
 * @returns {Promise<Object>} Risultato della verifica
 */
async function verifyIban(iban) {
  try {
    const response = await fetch(IBAN_CHECKER_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ iban }),
    });

    if (!response.ok) {
      // Fallback a GET
      const getResponse = await fetch(`${IBAN_CHECKER_URL}?iban=${iban}`);
      if (!getResponse.ok) {
        return { iban, valid: null, error: `HTTP ${getResponse.status}` };
      }
      return await getResponse.json();
    }

    return await response.json();
  } catch (e) {
    return { iban, valid: null, error: e.message };
  }
}

module.exports = { detectIntent, extractIban, verifyIban };
