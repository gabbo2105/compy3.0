/**
 * Compy v4 — Search Engine Webhook (Node.js)
 *
 * Endpoint:
 *   POST /   — BM25 search + formattazione deterministica ($0, <5ms)
 *   GET  /health
 *
 * Questa è la versione Node.js del motore di ricerca BM25+ di Compy.
 * NON include il fallback AI/Pinecone — solo il search engine puro.
 *
 * IN:  { "message": "query", "threadId": "session_123" }
 * OUT: { "message": "<b>HTML</b>", "threadId": "session_123" }
 */

const express = require("express");
const cors = require("cors");
const { FieldWeightedBM25, tokenize } = require("./bm25_search");
const { formatAnswer } = require("./format_answer");
const { mdToHtml } = require("./markdown_to_html");
const { detectIntent } = require("./intent_detector");
const chunks = require("./chunks/index.json");

const app = express();
app.use(cors());
app.use(express.json());

// ── Inizializzazione BM25 ──
const bm25 = new FieldWeightedBM25(chunks);
console.log(`[BM25] Indice caricato: ${chunks.length} chunks`);

// ── Config ──
const BM25_SCORE_THRESHOLD = 5.0;
const PORT = process.env.PORT || 8000;

// ── Main webhook ──
app.post("/", (req, res) => {
  const { message, threadId } = req.body;

  if (!message || typeof message !== "string" || message.length === 0) {
    return res.status(400).json({ error: "message is required" });
  }

  const query = message.trim();
  const tid = threadId || `session_${Date.now()}`;

  // 1. Intent detection (IBAN, ecc.)
  const intent = detectIntent(query);
  if (intent) {
    const html = mdToHtml(intent.result.formatted);
    return res.json({ message: html, threadId: tid });
  }

  // 2. BM25 search
  const results = bm25.searchWithPhraseBoost(query, 10, 1.5);

  if (results.length === 0) {
    return res.json({
      message: "Non ho trovato informazioni su questo argomento nella knowledge base.",
      threadId: tid,
    });
  }

  const topScore = results[0][1];
  const topChunks = results.map(([idx, score]) => ({ ...chunks[idx], score: Math.round(score * 10000) / 10000 }));

  // 3. Relevance check: termini rari devono comparire nei risultati
  if (!checkRelevance(query, topChunks, bm25)) {
    return res.json({
      message: "Non ho trovato informazioni su questo argomento nella knowledge base.",
      threadId: tid,
    });
  }

  // 4. Formattazione deterministica
  if (topScore >= BM25_SCORE_THRESHOLD) {
    const md = formatAnswer(query, topChunks);
    const html = mdToHtml(md);
    return res.json({ message: html, threadId: tid });
  }

  // Score troppo basso → non trovato
  return res.json({
    message: "Non ho trovato informazioni su questo argomento nella knowledge base.",
    threadId: tid,
  });
});

// ── Health ──
app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "compy-search-engine", version: "4.0.0-nodejs", chunks: chunks.length });
});

// ── Start ──
app.listen(PORT, () => {
  console.log(`[Compy] Search engine in ascolto su http://localhost:${PORT}`);
});

// ── Relevance check ──
/**
 * Verifica che i termini rari della query compaiano nei top risultati.
 * Se un termine raro (es. nome fornitore come "edison") non appare
 * nei primi 3 risultati, il risultato non è pertinente.
 */
function checkRelevance(query, topChunks, bm25Engine) {
  const { COMPOUNDS } = require("./bm25_search");
  const queryTokens = tokenize(query, false);
  const compoundValues = new Set(Object.values(COMPOUNDS));
  const baseTokens = [...new Set(queryTokens)].filter((t) => !compoundValues.has(t));

  if (baseTokens.length === 0) return true;

  // Soglia: termini che compaiono in meno del 5% dei documenti
  const rareThreshold = Math.max(bm25Engine.docCount * 0.05, 3);

  // Controlla nei top 3 chunks combinati
  const combinedText = topChunks
    .slice(0, 3)
    .map((c) => (c.text || ""))
    .join(" ")
    .toLowerCase();

  for (const token of baseTokens) {
    const df = (bm25Engine.df.body || {})[token] || 0;
    if (df < rareThreshold) {
      if (!combinedText.includes(token)) {
        return false;
      }
    }
  }

  return true;
}
