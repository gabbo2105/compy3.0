/**
 * Formattatore deterministico dei risultati — nessun LLM, nessuna API.
 *
 * Formatta i chunk BM25 in risultati stile Google:
 * - Titolo (dal campo section)
 * - Snippet (prime righe rilevanti con contesto keyword)
 * - Link (se presente nel chunk)
 */

/**
 * Formatta i top chunk come risultati di ricerca. Pura manipolazione stringhe.
 *
 * @param {string} query - Query dell'utente
 * @param {Object[]} chunks - Array di chunk con text, section, doc_title, score
 * @returns {string} Risultati formattati in markdown
 */
function formatAnswer(query, chunks) {
  if (!chunks || chunks.length === 0) {
    return "Non ho trovato informazioni su questo argomento nella knowledge base.";
  }

  const top = chunks.slice(0, 3);
  const results = [];

  for (let i = 0; i < top.length; i++) {
    const chunk = top[i];

    // Salta se duplicato del primo risultato
    if (i > 0 && isDuplicate(chunk.text, top[0].text)) {
      continue;
    }

    const section = chunk.section || "";
    const text = chunk.text;
    const docTitle = chunk.doc_title || "";

    const title = extractTitle(section, docTitle);
    const snippet = extractSnippet(text, query, title);
    const link = extractLink(text);

    const parts = [];
    if (title) parts.push(`**${title}**`);
    if (snippet) parts.push(snippet);
    if (link) parts.push(link);

    if (parts.length > 0) {
      results.push(parts.join("\n"));
    }
  }

  if (results.length === 0) {
    return "Non ho trovato informazioni su questo argomento nella knowledge base.";
  }

  return results.join("\n\n---\n\n");
}

/**
 * Pulisce il titolo dai metadati di sezione.
 * Rimuove prefissi gerarchici tipo "Regole di risposta — Procedura firma..."
 */
function extractTitle(section, docTitle) {
  let title = section || docTitle;
  if (title.includes(" — ")) {
    title = title.split(" — ").pop();
  }
  if (title.includes(" > ")) {
    title = title.split(" > ").pop();
  }
  return title.trim();
}

/**
 * Estrae le righe più rilevanti dal chunk come snippet.
 * Salta le righe di gerarchia e i titoli duplicati.
 * Limita a ~300 caratteri.
 */
function extractSnippet(text, query, title) {
  const lines = text.split("\n");
  const bodyLines = [];

  for (const line of lines) {
    const stripped = line.trim();
    if (!stripped) continue;
    if (stripped.includes(" > ") && stripped.length < 150) continue;
    if (title && stripped === title) continue;
    bodyLines.push(stripped);
  }

  if (bodyLines.length === 0) return "";

  const snippetParts = [];
  let total = 0;

  for (const line of bodyLines) {
    if (total > 300) break;

    if (/^\d+[.)]\s/.test(line)) {
      snippetParts.push(line);            // Passi procedurali numerati
    } else if (line.endsWith("?")) {
      snippetParts.push(`**${line}**`);   // Domande in grassetto
    } else if (line.startsWith("- ") || line.startsWith("* ") || line.startsWith("• ")) {
      snippetParts.push(line);            // Liste
    } else {
      snippetParts.push(line);
    }
    total += line.length;
  }

  return snippetParts.join("\n");
}

/**
 * Estrae il primo link dal testo del chunk.
 */
function extractLink(text) {
  // Pattern: (Link: https://...)
  let match = text.match(/\(Link:\s*(https?:\/\/[^\s)]+)\s*\)/);
  if (match) {
    return `[Apri documento](${match[1]})`;
  }

  // Pattern: plain URL
  match = text.match(/(https?:\/\/[^\s)]+)/);
  if (match) {
    const url = match[1];
    if (url.includes("google.com") || url.includes("drive.google")) {
      return `[Apri documento](${url})`;
    }
  }

  return "";
}

/**
 * Controlla se due chunk sono sostanzialmente lo stesso contenuto.
 * Usa overlap di parole (Jaccard-like): >60% = duplicato.
 */
function isDuplicate(text1, text2) {
  const words1 = new Set(text1.toLowerCase().split(/\s+/));
  const words2 = new Set(text2.toLowerCase().split(/\s+/));
  if (words1.size === 0 || words2.size === 0) return false;

  let overlap = 0;
  for (const w of words1) {
    if (words2.has(w)) overlap++;
  }
  return overlap / Math.min(words1.size, words2.size) > 0.6;
}

module.exports = { formatAnswer };
