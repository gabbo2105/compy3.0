/**
 * Convertitore Markdown → HTML per il frontend.
 *
 * Il frontend si aspetta HTML semplice con:
 * - <b> per il grassetto
 * - <a href="..." target="_blank"> per i link
 * - <ul><li> per le liste
 * - <br> per gli a capo
 * - NO tag <html>, <body>, <head>, <p>
 */

/**
 * Converte markdown semplice in HTML per il frontend.
 *
 * @param {string} md - Testo in markdown
 * @returns {string} HTML pulito
 */
function mdToHtml(md) {
  if (!md) return "";

  let html = md;

  // Grassetto: **testo** → <b>testo</b>
  html = html.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");

  // Link: [testo](url) → <a href="url" target="_blank">testo</a>
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "<a href='$2' target='_blank'>$1</a>");

  // URL plain non già dentro <a>
  html = html.replace(/(?<!href='|href=")(https?:\/\/[^\s<"']+)/g, "<a href='$1' target='_blank'>$1</a>");

  // Linea orizzontale: --- → <hr>
  html = html.replace(/\n---\n/g, "<hr>");

  // Gestione liste (ul/ol)
  const lines = html.split("\n");
  const result = [];
  let inUl = false;
  let inOl = false;

  for (const line of lines) {
    const stripped = line.trim();

    // Lista non ordinata
    if (stripped.startsWith("- ")) {
      if (!inUl) {
        if (inOl) { result.push("</ol>"); inOl = false; }
        result.push("<ul>");
        inUl = true;
      }
      result.push(`<li>${stripped.slice(2)}</li>`);
      continue;
    }

    // Lista ordinata
    const olMatch = stripped.match(/^(\d+)[.)]\s+(.+)/);
    if (olMatch) {
      if (!inOl) {
        if (inUl) { result.push("</ul>"); inUl = false; }
        result.push("<ol>");
        inOl = true;
      }
      result.push(`<li>${olMatch[2]}</li>`);
      continue;
    }

    // Chiudi liste se aperte
    if (inUl) { result.push("</ul>"); inUl = false; }
    if (inOl) { result.push("</ol>"); inOl = false; }

    // Inline code: `testo` → <code>testo</code>
    const processed = stripped.replace(/`([^`]+)`/g, "<code>$1</code>");

    if (processed) {
      result.push(processed);
    } else {
      result.push("<br>");
    }
  }

  // Chiudi liste rimaste aperte
  if (inUl) result.push("</ul>");
  if (inOl) result.push("</ol>");

  html = result.join("");

  // Pulisci <br> multipli
  html = html.replace(/(<br>){2,}/g, "<br>");

  // Rimuovi <br> iniziali e finali
  html = html.trim();
  if (html.startsWith("<br>")) html = html.slice(4);
  if (html.endsWith("<br>")) html = html.slice(0, -4);

  return html.trim();
}

module.exports = { mdToHtml };
