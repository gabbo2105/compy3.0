# Compy Search Engine — Node.js

Conversione del search engine BM25+ di Compy in Node.js.
Solo il motore di ricerca puro, senza fallback AI/Pinecone.

## Struttura

```
ortu/
├── server.js            ← Server Express (webhook)
├── bm25_search.js       ← Motore BM25+ con pesi per campo
├── format_answer.js     ← Formattatore deterministico risultati
├── markdown_to_html.js  ← Convertitore MD → HTML
├── intent_detector.js   ← Rilevamento IBAN
├── chunks/
│   └── index.json       ← Indice pre-costruito (602 chunks)
├── package.json
└── README.md
```

## Avvio

```bash
npm install
npm start
# → http://localhost:8000
```

## API

### POST /
```json
// Request
{ "message": "procedura inserimento contratto eni", "threadId": "123" }

// Response
{ "message": "<b>Procedura inserimento contratto Eni</b>...", "threadId": "123" }
```

### GET /health
```json
{ "status": "ok", "service": "compy-search-engine", "version": "4.0.0-nodejs", "chunks": 602 }
```

## Come funziona il motore BM25+

Ogni commento nel codice spiega il funzionamento. In sintesi:

1. **Tokenizzazione** — Il testo viene spezzato in parole, rimosse le stop words italiane, rilevati i termini composti ("firma digitale" → `firma_digitale`), espansi gli acronimi (PEC → posta certificata)

2. **Indicizzazione** — Ogni chunk viene indicizzato su 3 campi separati:
   - `section` (titolo sezione) — peso 3x
   - `doc_title` (titolo documento) — peso 2x
   - `body` (testo completo) — peso 1x

3. **Scoring BM25+** — Per ogni termine della query, calcola:
   - **IDF**: quanto è raro il termine (raro = più valore)
   - **TF normalizzato**: quante volte appare, con rendimenti decrescenti
   - **Delta**: bonus fisso (variante BM25+ di Lv & Zhai 2011)

4. **Bonus copertura** — Se il titolo sezione contiene tutti i termini della query → score ×2

5. **Boost frase** — Se la frase esatta appare nel titolo o nel body → boost aggiuntivo

6. **Controllo rilevanza** — Verifica che i termini rari (es. nomi fornitori) compaiano nei risultati

## Parametri BM25

| Parametro | Valore | Significato |
|-----------|--------|-------------|
| k1 | 1.2 | Saturazione TF (1.2 = equilibrato) |
| b | 0.5 | Normalizzazione lunghezza (0.5 = moderata) |
| delta | 1.0 | Bonus BM25+ per match |
| threshold | 5.0 | Score minimo per considerare un risultato valido |

## Dipendenze

Solo `express` e `cors`. Zero dipendenze AI/ML.
