/**
 * Field-Weighted BM25+ Search Engine (Node.js)
 *
 * Come Elasticsearch/Solr: il campo section/title ha peso 3x rispetto al body.
 * Così "procedura inserimento eni" trova il chunk intitolato
 * "Procedura di inserimento contratto Eni" invece di uno che menziona "eni" nel body.
 *
 * Caratteristiche:
 * - BM25+ variant (Lv & Zhai, 2011) — delta=1.0 evita che documenti lunghi vengano penalizzati
 * - Field weighting: section × 3.0, doc_title × 2.0, body × 1.0
 * - Rilevamento termini composti ("firma digitale" → "firma_digitale")
 * - Espansione acronimi (PEC, SPID, CF, ecc.)
 * - Indicizzazione duale con normalizzazione accenti
 * - Bonus prossimità frase
 * - k1=1.2, b=0.5 ottimizzati per documenti FAQ/procedure
 */

// ── Stop words italiane ──
const STOP_WORDS = new Set([
  "il", "lo", "la", "i", "gli", "le", "un", "uno", "una",
  "di", "del", "dello", "della", "dei", "degli", "delle",
  "a", "al", "allo", "alla", "ai", "agli", "alle",
  "da", "dal", "dallo", "dalla", "dai", "dagli", "dalle",
  "in", "nel", "nello", "nella", "nei", "negli", "nelle",
  "su", "sul", "sullo", "sulla", "sui", "sugli", "sulle",
  "con", "per", "tra", "fra", "e", "o", "ma", "che", "se",
  "non", "come", "cosa", "dove", "quando", "chi", "questo",
  "quello", "è", "sono", "ha", "ho", "può", "essere", "fare",
  "si", "ci", "ne", "mi", "ti", "vi", "anche", "già", "più",
  "molto", "poi", "ancora", "qui", "ogni", "suo", "sua",
]);

// ── Termini composti di dominio ──
// Quando due parole consecutive formano un concetto unico,
// vengono unite in un singolo token (es. "firma_digitale").
// Questo migliora il matching perché il motore cerca il concetto intero.
const COMPOUNDS = {
  "firma|digitale": "firma_digitale",
  "codice|fiscale": "codice_fiscale",
  "partita|iva": "partita_iva",
  "posta|elettronica": "posta_elettronica",
  "posta|certificata": "posta_certificata",
  "energia|elettrica": "energia_elettrica",
  "gas|naturale": "gas_naturale",
  "bonus|sociale": "bonus_sociale",
  "mercato|libero": "mercato_libero",
  "maggior|tutela": "maggior_tutela",
  "diritto|ripensamento": "diritto_ripensamento",
  "diritto|recesso": "diritto_recesso",
  "registrazione|vocale": "registrazione_vocale",
  "extra|commodity": "extra_commodity",
  "dati|errati": "dati_errati",
  "attesa|dati": "attesa_dati",
  "inserimento|contratto": "inserimento_contratto",
  "inserimento|contratti": "inserimento_contratto",
  "codice|pod": "codice_pod",
  "codice|pdr": "codice_pdr",
  "linea|fissa": "linea_fissa",
  "fibra|ottica": "fibra_ottica",
  "sky|tv": "sky_tv",
  "gestione|obiezioni": "gestione_obiezioni",
  "bolletta|gas": "bolletta_gas",
  "bolletta|luce": "bolletta_luce",
};

// ── Espansione acronimi ──
// Quando un utente scrive un acronimo (es. "PEC"),
// il motore aggiunge i sinonimi alla query per migliorare il recall.
const EXPANSIONS = {
  pec: ["posta_elettronica", "posta", "certificata"],
  cf: ["codice_fiscale", "codice", "fiscale"],
  spid: ["identità", "digitale"],
  cie: ["carta", "identità"],
  pod: ["punto", "prelievo", "codice_pod"],
  pdr: ["punto", "riconsegna", "codice_pdr"],
  pun: ["prezzo", "unico", "nazionale"],
  psv: ["punto", "scambio", "virtuale"],
  nds: ["assicurazione", "polizza"],
  tlc: ["telecomunicazione"],
  crm: ["portale", "gestionale"],
  otp: ["password", "temporanea", "verifica"],
  vpn: ["connessione", "remoto"],
  fttc: ["fibra", "cabinet"],
  ftth: ["fibra", "casa"],
};

// ── Utility: rimuovi accenti ──
/**
 * "è" → "e", "à" → "a", ecc.
 * Permette di trovare "perche" anche se nel documento c'è "perché".
 */
function stripAccents(text) {
  return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

// ── Tokenizer ──
/**
 * Trasforma un testo in una lista di token (parole significative).
 *
 * Passaggi:
 * 1. Lowercase + estrazione parole alfanumeriche
 * 2. Rimozione stop words (articoli, preposizioni, ecc.)
 * 3. Rilevamento composti: se due parole consecutive sono un composto noto,
 *    aggiunge il token composto E i singoli componenti
 * 4. Aggiunge varianti senza accenti
 * 5. (solo query) Espande acronimi
 *
 * @param {string} text - Testo da tokenizzare
 * @param {boolean} expandQuery - Se true, espande acronimi (solo per le query, non per i documenti)
 * @returns {string[]} Lista di token
 */
function tokenize(text, expandQuery = false) {
  const textLower = text.toLowerCase();
  const rawTokens = textLower.match(/[a-zà-ú0-9]+/g) || [];
  const lemmas = rawTokens.filter((t) => !STOP_WORDS.has(t) && t.length > 1);

  // Rilevamento composti
  const tokens = [];
  let i = 0;
  while (i < lemmas.length) {
    if (i + 1 < lemmas.length) {
      const bigram = `${lemmas[i]}|${lemmas[i + 1]}`;
      if (COMPOUNDS[bigram]) {
        tokens.push(COMPOUNDS[bigram]); // Token composto
        tokens.push(lemmas[i]);          // + componente 1
        tokens.push(lemmas[i + 1]);      // + componente 2
        i += 2;
        continue;
      }
    }
    tokens.push(lemmas[i]);
    i += 1;
  }

  // Varianti senza accenti (indicizzazione duale)
  const extra = [];
  for (const t of tokens) {
    const stripped = stripAccents(t);
    if (stripped !== t) {
      extra.push(stripped);
    }
  }
  tokens.push(...extra);

  // Espansione acronimi (solo a query-time)
  if (expandQuery) {
    for (const t of [...tokens]) {
      if (EXPANSIONS[t]) {
        tokens.push(...EXPANSIONS[t]);
      }
    }
  }

  return tokens;
}

// ── Field-Weighted BM25+ ──

/**
 * Motore di ricerca BM25+ con pesi per campo.
 *
 * COME FUNZIONA BM25+:
 *
 * BM25 (Best Matching 25) è l'algoritmo di ranking usato da Google, Elasticsearch, Solr.
 * Per ogni termine della query, calcola un punteggio per ogni documento basato su:
 *
 * 1. TF (Term Frequency) — quante volte il termine appare nel documento
 *    Più appare, più è rilevante, MA con rendimenti decrescenti:
 *    tf=1 → 0.52, tf=2 → 0.69, tf=10 → 0.89 (non lineare)
 *
 * 2. IDF (Inverse Document Frequency) — quanto è raro il termine nell'indice
 *    "inserimento" appare in 50 chunk → IDF basso → poco discriminante
 *    "edison" appare in 2 chunk → IDF alto → molto discriminante
 *    Formula: log((N - df + 0.5) / (df + 0.5) + 1)
 *
 * 3. Document Length Normalization — documenti lunghi non devono essere favoriti
 *    Un chunk di 500 parole con tf=3 vale meno di uno di 50 parole con tf=3
 *    Controllato dal parametro b (0=nessuna normalizzazione, 1=piena)
 *
 * 4. Delta (BM25+ specifico) — bonus fisso per ogni match
 *    Evita che documenti molto lunghi ricevano score ~0.
 *    Aggiunto da Lv & Zhai (2011) per correggere un difetto di BM25 classico.
 *
 * FIELD WEIGHTING:
 * Ogni chunk ha 3 campi, ognuno con un peso diverso:
 *   - section (titolo sezione):  peso 3.0 — match nel titolo vale 3x
 *   - doc_title (titolo doc):    peso 2.0 — match nel titolo doc vale 2x
 *   - body (testo completo):     peso 1.0 — match nel body vale 1x
 *
 * Score finale = section_score × 3.0 + doc_title_score × 2.0 + body_score × 1.0
 *
 * SECTION COVERAGE BONUS:
 * Se il titolo della sezione contiene TUTTI i termini della query,
 * il punteggio viene moltiplicato fino a 2x.
 * Es: query "inserimento contratto eni" + section "Procedura inserimento contratto Eni"
 *     → coverage 100% → bonus 2x
 *
 * @param {Object[]} chunks - Array di chunk dal file index.json
 * @param {number} k1 - Controlla la saturazione del TF (default 1.2)
 * @param {number} b - Controlla la normalizzazione per lunghezza (default 0.5)
 * @param {number} delta - Bonus BM25+ per ogni match (default 1.0)
 */
class FieldWeightedBM25 {
  static FIELD_WEIGHTS = {
    section: 3.0,
    doc_title: 2.0,
    body: 1.0,
  };

  constructor(chunks, k1 = 1.2, b = 0.5, delta = 1.0) {
    this.chunks = chunks;
    this.k1 = k1;
    this.b = b;
    this.delta = delta;
    this.docCount = chunks.length;

    // Strutture dati per ogni campo
    this.fields = {};    // campo → array di array di token per documento
    this.tfMaps = {};    // campo → array di mappe {termine: conteggio} per documento
    this.df = {};        // campo → mappa {termine: in quanti documenti appare}
    this.avgDl = {};     // campo → lunghezza media dei documenti nel campo

    for (const field of Object.keys(FieldWeightedBM25.FIELD_WEIGHTS)) {
      const fieldTokens = [];
      const fieldTf = [];
      const fieldDf = {};

      for (const chunk of chunks) {
        let text = "";
        if (field === "body") text = chunk.text || "";
        else if (field === "section") text = chunk.section || "";
        else if (field === "doc_title") text = chunk.doc_title || "";

        const tokens = tokenize(text, false);
        fieldTokens.push(tokens);

        // Term Frequency: conta quante volte ogni termine appare in questo documento
        const tf = {};
        for (const t of tokens) {
          tf[t] = (tf[t] || 0) + 1;
        }
        fieldTf.push(tf);

        // Document Frequency: in quanti documenti appare questo termine
        for (const t of new Set(tokens)) {
          fieldDf[t] = (fieldDf[t] || 0) + 1;
        }
      }

      this.fields[field] = fieldTokens;
      this.tfMaps[field] = fieldTf;
      this.df[field] = fieldDf;
      const totalLen = fieldTokens.reduce((sum, t) => sum + t.length, 0);
      this.avgDl[field] = totalLen / Math.max(this.docCount, 1);
    }
  }

  /**
   * Calcola lo score BM25+ per un singolo campo di un singolo documento.
   *
   * Per ogni termine della query presente nel documento:
   *   score += IDF × (TF_normalizzato + delta)
   *
   * dove TF_normalizzato = (tf × (k1 + 1)) / (tf + k1 × (1 - b + b × dl/avgdl))
   *
   * @param {string[]} queryTokens - Token della query
   * @param {string} field - Nome del campo (section, doc_title, body)
   * @param {number} idx - Indice del documento nell'array chunks
   * @returns {number} Score BM25+ per questo campo/documento
   */
  _bm25FieldScore(queryTokens, field, idx) {
    const dl = this.fields[field][idx].length;  // Lunghezza documento in questo campo
    const tfMap = this.tfMaps[field][idx];        // Frequenze termini per questo doc
    const avgDl = this.avgDl[field];              // Lunghezza media
    const df = this.df[field];                    // Document frequencies
    let score = 0.0;

    for (const term of queryTokens) {
      if (!df[term]) continue;             // Termine non presente in nessun documento
      const tf = tfMap[term] || 0;
      if (tf === 0) continue;              // Termine non presente in QUESTO documento

      const termDf = df[term];

      // IDF: quanto è raro questo termine? Più raro = più valore
      const idf = Math.log((this.docCount - termDf + 0.5) / (termDf + 0.5) + 1.0);

      // TF normalizzato: quante volte appare, con rendimenti decrescenti
      // b controlla quanto la lunghezza del documento penalizza
      const tfNorm = (tf * (this.k1 + 1)) / (tf + this.k1 * (1 - this.b + this.b * dl / Math.max(avgDl, 1)));

      // Score = IDF × (TF_norm + delta)
      // delta è il bonus BM25+ che evita score troppo bassi per documenti lunghi
      score += idf * (tfNorm + this.delta);
    }

    return score;
  }

  /**
   * Calcola la copertura dei termini della query nel titolo sezione.
   * Usato per il bonus di copertura: se il titolo contiene tutti i termini
   * della query, è quasi certamente il risultato giusto.
   *
   * I termini composti (firma_digitale) vengono esclusi dal conteggio se
   * i loro componenti individuali sono già nella query.
   *
   * @param {string[]} queryTokens - Token della query
   * @param {string} section - Titolo della sezione
   * @returns {number} Frazione di termini matchati (0.0 - 1.0)
   */
  _queryTermCoverage(queryTokens, section) {
    const sectionTokens = new Set(tokenize(section, false));
    const compoundValues = new Set(Object.values(COMPOUNDS));

    let baseTokens = [...new Set(queryTokens)].filter((t) => !compoundValues.has(t));
    if (baseTokens.length === 0) baseTokens = [...new Set(queryTokens)];
    if (baseTokens.length === 0) return 0.0;

    const matched = baseTokens.filter((t) => sectionTokens.has(t)).length;
    return matched / baseTokens.length;
  }

  /**
   * Ricerca BM25+ con pesi per campo e bonus copertura sezione.
   *
   * Per ogni documento:
   * 1. Calcola score BM25+ per ogni campo (section, doc_title, body)
   * 2. Score totale = Σ (field_score × field_weight)
   * 3. Se il titolo sezione contiene >50% dei termini query → bonus fino a 2x
   *
   * @param {string} query - Query dell'utente
   * @param {number} topK - Numero massimo di risultati
   * @returns {Array<[number, number]>} Array di [indice_chunk, score] ordinato per score
   */
  search(query, topK = 10) {
    const queryTokens = tokenize(query, true); // expand_query=true per la query
    if (queryTokens.length === 0) return [];

    const scores = [];

    for (let idx = 0; idx < this.docCount; idx++) {
      let total = 0.0;

      // Score per ogni campo, moltiplicato per il peso del campo
      for (const [field, weight] of Object.entries(FieldWeightedBM25.FIELD_WEIGHTS)) {
        const fieldScore = this._bm25FieldScore(queryTokens, field, idx);
        total += fieldScore * weight;
      }

      if (total > 0) {
        // Bonus copertura sezione
        const section = this.chunks[idx].section || "";
        const coverage = this._queryTermCoverage(queryTokens, section);

        // coverage 1.0 (tutti i termini matchano) → bonus 2.0x
        // coverage 0.75 (3/4 matchano) → bonus 1.5x
        // coverage 0.5 → bonus 1.0x (nessun cambiamento)
        // coverage < 0.5 → nessun bonus
        if (coverage > 0.5) {
          const bonus = 1.0 + (coverage - 0.5) * 2.0;
          total *= bonus;
        }

        scores.push([idx, total]);
      }
    }

    scores.sort((a, b) => b[1] - a[1]);
    return scores.slice(0, topK);
  }

  /**
   * Ricerca con boost per prossimità frase.
   *
   * Dopo la ricerca BM25+ base, applica un moltiplicatore extra:
   * - Frase esatta nel titolo sezione → boost × 2
   * - Frase esatta nel body → boost × 1
   * - Bigramma nel titolo → boost × 0.75
   *
   * @param {string} query - Query dell'utente
   * @param {number} topK - Numero massimo di risultati
   * @param {number} phraseBoost - Moltiplicatore (default 1.5)
   * @returns {Array<[number, number]>} Array di [indice_chunk, score]
   */
  searchWithPhraseBoost(query, topK = 10, phraseBoost = 1.5) {
    const baseResults = this.search(query, topK * 2);
    if (baseResults.length === 0) return [];

    const queryLower = query.toLowerCase().trim();
    const queryTerms = queryLower.split(/\s+/).filter((t) => !STOP_WORDS.has(t));

    const boosted = [];
    for (let [idx, score] of baseResults) {
      const sectionLower = (this.chunks[idx].section || "").toLowerCase();
      const docLower = this.chunks[idx].text.toLowerCase();

      // Frase esatta nel titolo → boost massiccio
      if (sectionLower.includes(queryLower)) {
        score *= phraseBoost * 2.0;
      } else if (docLower.includes(queryLower)) {
        score *= phraseBoost;
      } else if (queryTerms.length >= 2) {
        // Match bigramma nel titolo
        for (let i = 0; i < queryTerms.length - 1; i++) {
          const bigram = `${queryTerms[i]} ${queryTerms[i + 1]}`;
          if (sectionLower.includes(bigram)) {
            score *= 1.0 + (phraseBoost - 1.0) * 0.75;
            break;
          }
        }
      }

      boosted.push([idx, score]);
    }

    boosted.sort((a, b) => b[1] - a[1]);
    return boosted.slice(0, topK);
  }
}

module.exports = { FieldWeightedBM25, tokenize, STOP_WORDS, COMPOUNDS, EXPANSIONS };
